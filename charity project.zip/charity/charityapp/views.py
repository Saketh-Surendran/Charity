from django.shortcuts import render
from.models import*
from django.contrib import messages
from django.http import HttpResponseRedirect, HttpResponse
from django.shortcuts import render, redirect
from charityapp.models import tbl_donor  # Import your Donor model
from django.contrib import messages
from django.core.files.storage import FileSystemStorage
from django.utils.datastructures import MultiValueDictKeyError



def index(request):
    return render(request,'index.html')

def contact(request):
    if request.method == "POST":
        name=request.POST['name']
        email=request.POST['email']
        phone=request.POST['phone']
        msg = request.POST['msg']
        tbl_contact(name=name,email=email,phone=phone,msg=msg).save()
        return render(request,'index.html')
    else:
        return render(request,'contact.html')




    
def login(request):
    if request.method == "POST":
        email = request.POST['email']
        password = request.POST['password']
        var= tbl_donor.objects.all().filter(email=email, password=password,utype='user')
        var2=tbl_receiver.objects.all().filter(email=email, password=password)
        var3=tbl_donor.objects.all().filter(email=email,password=password,utype='admin')
        if var:
            for i in var:
                request.session['id'] = i.id
            return render(request,'donor/donor_home.html')
        
        elif var2:
            for i in var2:
                request.session['id'] = i.id
            return render(request,'receiver/receiver_home.html')
        
        elif var3:
            for i in var3:
                request.session['id'] = i.id
            return render(request,'admin/admin_home.html')
        
        else:
            txt = """<script>alert("Invalid user Credentials....");window.location='/';</script>"""
            return HttpResponse(txt)
           
    else:
        return render(request, 'login.html')

    
def logout(request):
    if request.session.has_key('id'):
        del request.session['id']
        logout(request)
        return render(request,'index.html')



    
    
    
    
    # ..........donor............
    

    
def donor_home(request):
        return render(request, 'donor/donor_home.html')


def donor_reg(request):
        if request.method == "POST":
                name=request.POST['name']
                email=request.POST['email']
                address=request.POST['address']
                gender=request.POST['gender']
                phone=request.POST['phone']
                dob=request.POST['dob']
                password=request.POST['password']
                tbl_donor(name=name,email=email,address=address,gender=gender,phone=phone,dob=dob,password=password,status='pending',utype='user').save()
                msg="Registration successful!"
                return render(request,'donor_reg.html',{"msg":msg})
        return render(request,'donor_reg.html')
    
    
def donor_profile(request):
    id = request.session['id']
    data = tbl_donor.objects.all().filter(id=id)
    return render(request,'donor/donor_profile.html',{'data':data})


def edit_donorprofile(request,id):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        password = request.POST.get('password')
        dob = request.POST.get('dob')
        gender = request.POST.get('gender')
        tbl_donor.objects.all().filter(id=id).update(name=name,email=email,address=address,gender=gender,phone=phone,dob=dob,password=password)
        return HttpResponseRedirect('/donor_profile/')
    else:
        nvar=tbl_donor.objects.all().filter(id=id)
        return render(request,'donor/edit_donorprofile.html',{'nvar':nvar})
    
    
def donor_food(request):
    if request.method == "POST":
        id = request.session['id']
        name=request.POST['name']
        if name == "Other":
            name = request.POST.get("otherfoodname")
        quantity=request.POST['quantity']
        expire=request.POST['expire']
        instance=tbl_donor.objects.get(id=id)
        tbl_FoodDonation(donor_id=instance,name=name,quantity=quantity,expire=expire,status='Available',fd_status='Pending').save()
        return render(request,'donor/donor_home.html')
    return render(request,'donor/donor_food.html')


def donor_funding(request):
    if request.method == "POST":
        id = request.session['id']
        name = request.POST['name']
        amount = request.POST['amount']
        date = request.POST['date']
        instance = tbl_donor.objects.get(id=id)
        tbl_funding(donor_id=instance,name=name,amount=amount,date=date,status='Available',fund_status='pending').save()
        return render(request,'donor/donor_home.html')
    return render(request,'donor/donor_funding.html')


def donor_medicine(request):
    if request.method == "POST":
        id = request.session['id']
        name = request.POST['name']
        if name == "Other":
            name = request.POST.get('othermedicinename')
        quantity=request.POST['quantity']
        expire=request.POST['expire']
        instance = tbl_donor.objects.get(id=id)
        tbl_Medicine(donor_id=instance,name=name,quantity=quantity,expire=expire,status='Available',med_status='pending').save()
        return render(request,'donor/donor_medicine.html')
    return render(request,'donor/donor_medicine.html')


def donor_viewMessage(request):
    data=tbl_message.objects.all()
    return render(request,'donor/donor_viewMessage.html',{'data':data})


def donor_viewReceiverNeed(request):
    id = request.session['id']
    data=tbl_buyProduct.objects.all().filter(donor_id=id).select_related('receiver_id','food_id','medicine_id','fund_id')
    return render(request,'donor/donor_viewReceiverNeed.html',{'data':data})

     

        

        
        

    

        

       
    



# ......receiver.......



def receiver_home(request):
        return render(request,'receiver/receiver_home.html')


def receiver_reg(request):
        if request.method == "POST":
                name=request.POST['name']
                email=request.POST['email']
                address=request.POST['address']
                gender=request.POST['gender']
                phone=request.POST['phone']
                dob=request.POST['dob']
                password=request.POST['password']
                img=request.FILES['img']
                id_card=request.POST['id_card']
                account_detail=request.POST['account_detail']
                tbl_receiver(name=name,email=email,address=address,gender=gender,phone=phone,dob=dob,password=password,img=img,id_card=id_card,account_detail=account_detail,status='pending').save()
                msg="Registration successful!"
                return render(request,'receiver_reg.html',{"msg":msg})
        return render(request,'receiver_reg.html')
    
    
def receiver_profile(request):
        id=request.session['id']
        data=tbl_receiver.objects.all().filter(id=id)
        print("receiver...",data)
        return render(request,'receiver/receiver_profile.html',{'data':data}) 
    

def edit_receiverprofile(request,id):
    if request.method == 'POST':
                name=request.POST['name']
                email=request.POST['email']
                address=request.POST['address']
                gender=request.POST['gender']
                phone=request.POST['phone']
                dob=request.POST['dob']
                password=request.POST['password']
                id_card=request.POST['id_card']
                account_detail=request.POST['account_detail']
                try:
                    img_c = request.FILES['img']
                    fs = FileSystemStorage()
                    file = fs.save(img_c.name, img_c)
                except MultiValueDictKeyError:
                    file = tbl_receiver.objects.get(id=id).img

                tbl_receiver.objects.all().filter(id=id).update(name=name,email=email,address=address,gender=gender,phone=phone,dob=dob,password=password,img=file,id_card=id_card,account_detail=account_detail)
                return HttpResponseRedirect('/receiver_profile/')
    else:
        var=tbl_receiver.objects.all().filter(id=id)
        return render(request,'receiver/edit_receiverprofile.html',{'var':var})
    
def receiver_addmessage(request):
    if request.method == "POST":
        id = request.session['id']
        msg = request.POST['msg']
        instance = tbl_receiver.objects.get(id=id)
        tbl_message(receiver_id=instance,msg=msg).save()
        return render(request,'receiver/receiver_home.html')
    return render(request,'receiver/receiver_addmessage.html')

def receiver_viewFood(request):
    data=tbl_FoodDonation.objects.all().filter(fd_status="approved")
    return render(request,'receiver/receiver_viewFood.html',{'data':data})  

def receiver_viewFund(request):
    data=tbl_funding.objects.all().filter(fund_status="approved")
    return render(request,'receiver/receiver_viewFund.html',{'data':data})

def receiver_viewMedicine(request):
    data=tbl_Medicine.objects.all().filter(med_status="approved")
    return render(request,'receiver/receiver_viewMedicine.html',{'data':data})
     
    
def receiver_getFood(request):
    id=request.GET['id']
    data=tbl_FoodDonation.objects.all().filter(id=id)
    return render(request,'receiver/receiver_buyFood.html',{'data':data})
        
        
        
def receiver_buyFood(request):
    if request.method == 'POST':
        id = request.session['id']
        idd = request.POST.get('id')
        dd = request.POST.get('donor_id')
        uid = tbl_receiver.objects.get(id=id)
        fid = tbl_FoodDonation.objects.get(id=idd)
        did = tbl_donor.objects.get(id=dd)
        quantity = request.POST['quantity']
        fid.status = 'Unavailable'
        fid.save()
        tbl_buyProduct(receiver_id=uid, donor_id=did,food_id=fid, quantity=quantity).save()
        
        # tbl_FoodDonation.objects.filter(donor_id=id).update(status='Unavailable')
        
        return render(request, 'receiver/receiver_home.html')
    else:
        return render(request, 'receiver/receiver_buyFood.html')





       
def receiver_getMedicine(request):
    id=request.GET['id']
    data=tbl_Medicine.objects.all().filter(id=id)
    return render(request,'receiver/receiver_buyMedicine.html',{'data':data})



def receiver_buyMedicine(request):
    if request.method == 'POST':
        id = request.session['id']
        idd = request.POST.get('id')
        dd=request.POST.get('donor_id')
        uid = tbl_receiver.objects.get(id=id)
        fid = tbl_Medicine.objects.get(id=idd)
        did=tbl_donor.objects.get(id=dd)
        quantity = request.POST['quantity']
        fid.status = 'Unavailable'
        fid.save()
        tbl_buyProduct(receiver_id=uid, medicine_id=fid,donor_id=did, quantity=quantity).save()
        
        # tbl_FoodDonation.objects.filter(donor_id=id).update(status='Unavailable')
        
        return render(request, 'receiver/receiver_home.html')
    else:
        return render(request, 'receiver/receiver_buyMedicine.html')
    
    
    
def receiver_getFund(request):
    id=request.GET['id']
    data=tbl_funding.objects.all().filter(id=id)
    return render(request,'receiver/receiver_buyFund.html',{'data':data})


def receiver_buyFund(request):
    if request.method == 'POST':
        id = request.session['id']
        idd = request.POST.get('id')
        dd=request.POST.get('donor_id')
        uid = tbl_receiver.objects.get(id=id)
        fid = tbl_funding.objects.get(id=idd)
        did=tbl_donor.objects.get(id=dd)
        fid.status = 'Unavailable'
        fid.save()
        tbl_buyProduct(receiver_id=uid,donor_id=did, fund_id=fid).save()
        
        # tbl_FoodDonation.objects.filter(donor_id=id).update(status='Unavailable')
        
        return render(request, 'receiver/receiver_home.html')
    else:
        return render(request, 'receiver/receiver_buyMedicine.html')
    
    
    
def receiver_ViewDelivery(request):
    data=tbl_deliverer.objects.all().filter(status='pendings')
    return render(request,'receiver/receiver_ViewDelivery.html',{'data':data})



def receiver_needDeliverer(request):
    ii = request.GET['id']
    tbl_deliverer.objects.all().filter(id=ii).update(status='pending')
    return redirect('/receiver_ViewDelivery/')

def receiver_viewProcessedDeliverer(request):
    data=tbl_deliverer.objects.all()
    return render(request,'receiver/receiver_viewProcessedDeliverer.html',{'data':data})




    
    
    



    



    # ..........Admin............
    
    
def admin_home(request):
    return render(request,'admin/admin_home.html')


def admin_viewDonor(request):
    data = tbl_donor.objects.all().filter(status='pending')
    return render(request,'admin/admin_viewDonor.html',{'data':data})

def admin_viewReceiver(request):
    data = tbl_receiver.objects.all().filter(status='pending')
    return render(request,'admin/admin_viewReceiver.html',{'data':data})

def admin_approve_Donor(request):
    ii = request.GET['id']
    var = tbl_donor.objects.all().filter(id=ii).update(status='approved')
    return HttpResponseRedirect('/admin_viewDonor/')

def admin_reject_Donor(request):
    ii = request.GET['id']
    tbl_donor.objects.all().filter(id=ii).update(status='Rejected')
    return HttpResponseRedirect('/admin_viewDonor/')


def admin_approve_receiver(request):
    ii = request.GET['id']
    tbl_receiver.objects.all().filter(id=ii).update(status='approved')
    return HttpResponseRedirect('/admin_viewReceiver/')

def admin_reject_receiver(request):
    ii = request.GET['id']
    tbl_receiver.objects.all().filter(id=ii).update(status='Rejected')
    return HttpResponseRedirect('/admin_viewReceiver/')



def admin_viewFood(request):
    data=tbl_FoodDonation.objects.all().filter(fd_status='pending').select_related('donor_id')
    return render(request,'admin/admin_viewFood.html',{'data':data})

def admin_approve_food(request):
    ii = request.GET['id']
    tbl_FoodDonation.objects.all().filter(id=ii).update(fd_status='approved')
    return HttpResponseRedirect('/admin_viewFood/')

def admin_reject_food(request):
    ii = request.GET['id']
    tbl_FoodDonation.objects.all().filter(id=ii).update(fd_status='Rejected')
    return HttpResponseRedirect('/admin_viewFood/')


def admin_approve_fund(request):
    ii = request.GET['id']
    tbl_funding.objects.all().filter(id=ii).update(fund_status='approved')
    return HttpResponseRedirect('/admin_viewFund/')


def admin_reject_fund(request):
    ii = request.GET['id']
    tbl_funding.objects.all().filter(id=ii).update(fund_status='Rejected')
    return HttpResponseRedirect('/admin_viewFund/')


def admin_approve_medicine(request):
    ii = request.GET['id']
    tbl_Medicine.objects.all().filter(id=ii).update(med_status='approved')
    return HttpResponseRedirect('/admin_viewMedicine/')

def admin_reject_medicine(request):
    ii = request.GET['id']
    tbl_Medicine.objects.all().filter(id=ii).update(med_status='Rejected')
    return HttpResponseRedirect('/admin_viewMedicine/')

        
    
def admin_viewFund(request):
    data=tbl_funding.objects.all().filter(fund_status='pending').select_related('donor_id')
    return render(request,'admin/admin_viewFund.html',{'data':data})

def admin_viewMedicine(request):
    data=tbl_Medicine.objects.all().filter(med_status='pending').select_related('donor_id')
    return render(request,'admin/admin_viewMedicine.html',{'data':data})



def admin_deliverer(request):
    if request.method == "POST":
        name=request.POST['name']
        email=request.POST['email']
        address=request.POST['address']
        phone=request.POST['phone']
        dob=request.POST['dob']
        tbl_deliverer(name=name,email=email,address=address,phone=phone,dob=dob,status='pendings').save()
        return render(request,'admin/admin_deliverer.html')
    return render(request,'admin/admin_deliverer.html')


# def admin_receiverDelivery(request):
#     data = tbl_receiver.objects.all().filter(status='pending')
#     return HttpResponseRedirect('/admin_receiverDelivery/')

def admin_pendingDeliverer(request):
    data = tbl_deliverer.objects.all().filter(status='pending')
    return render(request,'admin/admin_pendingDeliverer.html',{'data':data})


def admin_alocateDeliverer(request):
    ii = request.GET['id']
    tbl_deliverer.objects.all().filter(id=ii).update(status='started')
    return HttpResponseRedirect('/admin_pendingDeliverer/')

def admin_viewprocessedList(request):
    data = tbl_deliverer.objects.all().filter(status='started')
    return render(request,'admin/admin_viewprocessedList.html',{'data':data})


def admin_completeDeliverer(request):
    ii = request.GET['id']
    tbl_deliverer.objects.all().filter(id=ii).update(status='completed')
    return HttpResponseRedirect('/admin_viewprocessedList/')

def admin_viewDcompletedlist(request):
    data = tbl_deliverer.objects.all().filter(status='completed')
    return render(request,'admin/admin_viewDcompletedlist.html',{'data':data})


    



    




    

    
    

